
import React from 'react';
import { motion } from 'framer-motion';
import { StickerInstance } from '../types';

interface StickerProps {
  sticker: StickerInstance;
  onRemove: (id: string) => void;
}

const Sticker: React.FC<StickerProps> = ({ sticker, onRemove }) => {
  return (
    <motion.div
      drag
      dragMomentum={false}
      initial={{ scale: 0, x: sticker.x, y: sticker.y }}
      animate={{ scale: sticker.scale, rotate: sticker.rotation }}
      className="absolute cursor-grab active:cursor-grabbing group z-50"
      style={{ left: 0, top: 0 }}
      onDoubleClick={() => onRemove(sticker.id)}
    >
      <img 
        src={sticker.url} 
        alt="sticker" 
        className="w-16 h-16 pointer-events-none drop-shadow-sm group-hover:drop-shadow-md transition-shadow" 
      />
      <div className="hidden group-hover:block absolute -top-1 -right-1 bg-white text-pink-400 rounded-full w-4 h-4 text-[10px] text-center shadow-sm cursor-pointer border border-pink-100">
        ×
      </div>
    </motion.div>
  );
};

export default Sticker;
