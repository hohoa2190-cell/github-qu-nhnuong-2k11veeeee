
import React from 'react';
import { motion } from 'framer-motion';
import { Sparkles, Trash2, Wand2 } from 'lucide-react';
import { Photo } from '../types';

interface PhotoFrameProps {
  photo: Photo;
  onRemove: (id: string) => void;
  onEnhance: (id: string) => void;
  onUpdateCaption: (id: string, newCaption: string) => void;
}

const PhotoFrame: React.FC<PhotoFrameProps> = ({ photo, onRemove, onEnhance, onUpdateCaption }) => {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.8, rotate: -5 }}
      animate={{ opacity: 1, scale: 1, rotate: photo.rotation }}
      whileHover={{ scale: 1.05, rotate: photo.rotation + 2 }}
      className="relative p-3 bg-white border-[12px] border-pink-100 rounded-2xl shadow-lg inline-block m-4 group overflow-visible w-full max-w-[300px]"
    >
      <div className="relative w-full aspect-square overflow-hidden rounded-lg bg-pink-50">
        <img 
          src={photo.url} 
          alt="Photobook entry" 
          className="w-full h-full object-cover transition-all duration-500"
          style={{ filter: photo.filter || 'none' }}
        />
        
        {photo.isAIProcessing && (
          <div className="absolute inset-0 bg-white/60 flex items-center justify-center backdrop-blur-sm">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ repeat: Infinity, duration: 1.5, ease: "linear" }}
            >
              <Sparkles className="text-pink-400 w-10 h-10" />
            </motion.div>
          </div>
        )}
      </div>

      <div className="mt-4 text-center">
        <textarea
          value={photo.caption}
          onChange={(e) => onUpdateCaption(photo.id, e.target.value)}
          className="w-full text-pink-500 font-handwriting text-lg bg-transparent border-none focus:ring-0 text-center resize-none placeholder-pink-200"
          placeholder="Tap to write a memory..."
          rows={1}
        />
      </div>

      {/* Controls Overlay */}
      <div className="absolute -top-3 -right-3 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
        <button
          onClick={() => onEnhance(photo.id)}
          disabled={photo.isAIProcessing}
          className="bg-white p-2 rounded-full shadow-md border border-pink-100 text-pink-400 hover:text-pink-600 hover:bg-pink-50 transition-colors"
          title="AI Magic Touch"
        >
          <Wand2 size={18} />
        </button>
        <button
          onClick={() => onRemove(photo.id)}
          className="bg-white p-2 rounded-full shadow-md border border-pink-100 text-red-300 hover:text-red-500 hover:bg-red-50 transition-colors"
          title="Remove"
        >
          <Trash2 size={18} />
        </button>
      </div>
    </motion.div>
  );
};

export default PhotoFrame;
